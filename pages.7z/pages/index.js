export default function Home() {
  return (
    <div style={{textAlign: 'center', marginTop: '50px'}}>
      <h1>مرحبا بك في مشروع Fellah-Tech 🌾</h1>
      <p>هذا مشروع Next.js جاهز للنشر على Vercel</p>
    </div>
  );
}
